//Michelle Lebel
//04/02/2021

#include <iostream>
#include <iomanip> // used for set precision resource:https://www.cplusplus.com/reference/iomanip/

using namespace std;

int main()
{
    //Declare variables initInv, AnuInt, months and years
    float initInvest, monDep, AnuInt, months, years;
    //Declare variables totalAm intAmt and yearTotInt
    float totalAm, intAmt, yearTotInt;


    //output for user
    cout << "********************************\n";
    cout << "********** Data Input **********\n";
    cout << "Initial Investment Amount: \n";
    cout << "Monthly Deposit: \n";
    cout << "Annual Interest: \n";
    cout << "Number of years: \n";

    //Wait for input to continue
    system("PAUSE");

    //Output questions grab input from user
    cout << "********************************\n";
    cout << "********** Data Input **********\n";
    cout << "Initial Investment Amount: $";
    cin >> initInvest;
    cout << "Monthly Deposit: $";
    cin >> monDep;
    cout << "Annual Interest: %";
    cin >> AnuInt;
    cout << "Number of years: ";
    cin >> years;
    months = years * 12;

    //Wait for input
    system("PAUSE");

    //Set total to initial investment
    totalAm = initInvest;

    //Display year data without monthly deposits
    cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
    cout << "==============================================================\n";
    cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
    cout << "--------------------------------------------------------------\n";


    for (int i = 0; i < years; i++) {

        //Calculate yearly interest
        intAmt = (totalAm) * ((AnuInt / 100));

        //Calculate end of year total
        totalAm = totalAm + intAmt;

        //Print results to table with two decimal points using setprecision https://www.cplusplus.com/reference/iomanip/setprecision/
        cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << intAmt << "\n";

    }

    //Set total to initial investment
    totalAm = initInvest;

    //Display year data with monthly deposits
    cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
    cout << "==============================================================\n";
    cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
    cout << "--------------------------------------------------------------\n";

    for (int i = 0; i < years; i++) {

        //yearly intrest is at zero at the begining of the year
        yearTotInt = 0;

        for (int j = 0; j < 12; j++) {

            //Calculate monthly interest
            intAmt = (totalAm + monDep) * ((AnuInt / 100) / 12);

            //Calculate end of month interest
            yearTotInt = yearTotInt + intAmt;

            //Calculate end of month total
            totalAm = totalAm + monDep + intAmt;

        }

        //Print results to table with two decimal points using setprecision https://www.cplusplus.com/reference/iomanip/setprecision/
        cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << yearTotInt << "\n";


    }

    return 0;
}